/**
 * 
 */
package tech;

import java.util.ArrayList;
import java.util.Scanner;

/**
 * @author Clare
 *
 */
public class GamePlay {

	// instance vars
	private static final double STARTING_BALANCE = 8000;
	private static final int STARTING_POSITION = 0;
	private static String playerChoice = null;
	private int numberOfSquares;
	private static int activePlayer;
	public static boolean correct;
	public static Scanner scanner = new Scanner(System.in);
	public static ArrayList<Players> players = new ArrayList<Players>();
	public static ArrayList<Square> properties = new ArrayList<Square>();

	/**
	 * 
	 */
	public GamePlay() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		GameIntro();
		playerName();

	}

	public static void GameIntro() {
		System.out.println(
				"Welcome to technopoly, do you you can be the next Bill Gatres and make it in the software industry?");

		// setting the number of players
		Players p1 = new Players(null, STARTING_BALANCE, STARTING_POSITION);

		Players p2 = new Players(null, STARTING_BALANCE, STARTING_POSITION);

		Players p3 = new Players(null, STARTING_BALANCE, STARTING_POSITION);

		Players p4 = new Players(null, STARTING_BALANCE, STARTING_POSITION);

		// Prompt the user

		System.out.println("Please enter the number of players from 2-4:");

		// Setting the playerChoice equal to the nextLine

		playerChoice = scanner.next();

		// Using a switch statement to decide how many players to add to the arrayList

		switch (playerChoice) {

		case "2":

			players.ensureCapacity(2);

			players.add(p1);

			players.add(p2);

			break;

		case "3":

			players.ensureCapacity(3);

			players.add(p1);

			players.add(p2);

			players.add(p3);

			break;

		case "4":

			players.ensureCapacity(4);

			players.add(p1);

			players.add(p2);

			players.add(p3);

			players.add(p4);

			break;

		default:

			// Display a message and recall the players class

			System.out.println("Please enter a number of players from 2-4, thanks!");

			GameIntro();
			

		}

		// Invoke the setPlayerNames Class

		// setPlayerNames();

	}
	
	public static void playerName () {
		for(int loop=0;loop<players.size();loop++) {
			correct=false;
		do {
			System.out.printf("Player %s enter your name please",(loop+1));
			playerChoice=scanner.next();
			boolean sameName=false;
			for(Players p: players) {
				if(p.getPlayerName()==null) {
					
				} else if(p.getPlayerName().equalsIgnoreCase(playerChoice)) {
					System.out.println("Duplicate names");
					sameName=true;
				}
			}
			if(sameName==false) {
				if(playerChoice==null) {
					System.out.println("Invalid input entry");
				} else {
					players.get(loop).setPlayerName(playerChoice);
					correct=true;
				}
			}
		} while(correct==false);
		
	}
		System.out.println("Welcome!");
		for(int loop=0;loop<players.size();loop++) {
			System.out.printf("Player %s : %s\n",(loop+1),players.get(loop).getPlayerName());
		}
	}
	/**
	 * 
	 */
	public static void setUpSquares() {
		GoTaxBreak go = new GoTaxBreak("0", "Go");
		Company cyberSec = new Company("1", "Kainos", "Cyber security division", 1, 400, 100, 150, 200);
		Company smartTesting = new Company("2", "Kainos", "Smart testing", 2, 400, 150, 200, 200);
		
		Company java = new Company("3", "Oracle", "Java", 3, 400, 100, 150, 200);
		Company oracleHQ = new Company("4", "Oracle", "Redwood City HQ", 4, 400, 250, 200, 200);
		Company mySql = new Company("5", "Oracle", "MySql", 5, 400, 250, 300, 200);

		Company qLanguage = new Company("6", "First Derivatives", "Q language", 6, 400, 250, 200, 200);
		Company kdb = new Company("7", "First Derivatives", "KDB+ Database", 7, 400, 200, 250, 200);
		Company firstDHq = new Company("8", "First Derivatives", "Newry HQ", 8, 400, 200, 250, 200);

		Company windows = new Company("9", "Microsoft", "Windows", 10, 400, 200, 250, 200);
		Company office = new Company("11", "Microsoft", "Office", 11, 400, 200, 250, 200);

		properties.ensureCapacity(12);
		properties.add(go);
		properties.add(cyberSec);
		properties.add(smartTesting);
		properties.add(java);
		properties.add(oracleHQ);
		properties.add(mySql);
		properties.add(qLanguage);
		properties.add(kdb);
		properties.add(firstDHq);
		properties.add(windows);
		properties.add(office);
			
	}
	public static void playerTurn() {
		System.out.println("Ok lets begin! ");
		System.out.println("\n"+players.get(activePlayer));
		
		
	}
}

package tech;

/**
 * class to incorporate the Go and Tax Break squares into the Technopoloy game
 * 
 * @author jonathanjames
 *
 */
public class GoTaxBreak extends Square {

	// instance vars
	private String squareName;
	private String message;

	/**
	 * Default constructor
	 */
	public GoTaxBreak() {
	}

	/**
	 * Constructor with args
	 * 
	 * @param squareName
	 * @param message
	 */
	public GoTaxBreak(String squareName, String message) {
		this.squareName = squareName;
		this.message = message;
	}

	/**
	 * Overridden method from the Squares class to display all details about the Go
	 * and Tax Break Squares
	 */
	@Override
	public void displayAll() {
		System.out.println("Hello X you have landed on the " + this.squareName + "square");
		System.out.println(this.message);
	}

}

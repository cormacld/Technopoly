/**
 * 
 */
package tech;

/**
 * @author jonathanjames Class to enable the authors to create objects of the
 *         type square, based upon the different squares upon the digital
 *         board-game
 *
 */
public abstract class Square {

	private String squareName;

	/**
	 * Default constructor
	 */
	public Square() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * Constructor with args
	 */
	public Square(String squareName) {
		this.squareName = squareName;
	}

	/**
	 * @return the squareName
	 */
	public String getSquareName() {
		return squareName;
	}

	/**
	 * @param squareName the squareName to set
	 */
	public void setSquareName(String squareName) {
		this.squareName = squareName;
	}

	public abstract void displayAll();

}


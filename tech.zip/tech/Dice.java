package tech;

import java.util.Random;

/**
 * Class to return a value between 2 and 12 inclusive, to simulate a digital
 * dice.
 * 
 * @author jonathanjames
 *
 */
public class Dice {

	public Dice() {

	}

	/**
	 * Method to return a random number between 2 and 12 inclusive.
	 * 
	 * @return
	 */
	public static int rollDice() {
		Random r = new Random();
		int roll = r.nextInt(11) + 1;
		System.out.println("You have rolled a: " + roll);
		return roll;

	}
}



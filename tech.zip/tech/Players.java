/**
 * 
 */
package tech;

/**
 * @author jonathanjames Class to create objects of type player which will
 *         contain different details about each player such as player name,
 *         player balance and the position of the player within the digital
 *         board-game
 */
public class Players {

	private String playerName;
	private double playerBalance;
	private int playerPosition;


	/**
	 * 
	 */
	public Players() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * Constructor with args
	 * 
	 */
	public Players(String playerName, double playerBalance, int playerPosition) {
		this.playerName = playerName;
		this.playerBalance = playerBalance;
		this.playerPosition = playerPosition;
		
	}

	/**
	 * @return the playerName
	 */
	public String getPlayerName() {
		return playerName;
	}

	/**
	 * @param playerName the playerName to set
	 */
	public void setPlayerName(String playerName) {
		this.playerName = playerName;
	}

	/**
	 * @return the playerBalance
	 */
	public double getPlayerBalance() {
		return playerBalance;
	}

	/**
	 * @param playerBalance the playerBalance to set
	 */
	public void setPlayerBalance(double playerBalance) {
		this.playerBalance = playerBalance;
	}

	/**
	 * @return the playerPosition
	 */
	public int getPlayerPosition() {
		return playerPosition;
	}

	/**
	 * @param playerPosition the playerPosition to set
	 */
	public void setPlayerPosition(int playerPosition) {
		this.playerPosition = playerPosition;
	}

	

}
